  _____       _           _    _       _     
 |  __ \     (_)         | |  | |     | |    
 | |  | |_ __ ___   _____| |__| |_   _| |__  
 | |  | | '__| \ \ / / _ \  __  | | | | '_ \ 
 | |__| | |  | |\ V /  __/ |  | | |_| | |_) |
 |_____/|_|  |_| \_/ \___|_|  |_|\__,_|_.__/ 
 
 -------- DRIVEHUB WEB APPLICATIONS ---------
 
 About
 DriveHub is a comprehensive vehicle reservation and management system designed to facilitate seamless vehicle bookings, payments, and administration. The repository contains two main applications: DriveHub for users and Admin for managing data within DriveHub. 
 
 Self hosting instructions:
 1. Clone the repo:
 git clone https://github.com/ProgrammingProject2024SP3Team3/DriveHub.git
 
 2. Change directory
 cd DriveHub

 3. Check out the Fork-me branch:
 git checkout Fork-me
  
 4. Add executable bit
 chmod +x deploy.sh
 
 5. Run the deploy script
 ./deploy.sh
 
 6. Load the project in Visual Studio 2022, VS Code, or Rider.
 
 7. Change the database string in appsettings.Development.json to point at your server.
 
 8. Run the application to seed the database.
 
 Web Hosting:
 The DriveHub application was hosted at https://drivehub.au
 The DriveHub admin portal was hosted at https://portal.drivehub.au
 
 The DriveHub application allows users to: 
 - Register and manage their accounts 
 - Book and manage vehicle reservations 
 - Process payments securely using Stripe 
 - Generate and download PDF reports and invoices 
 
 The Admin application provides administrative capabilities to: 
 - Manage vehicle information 
 - Oversee user accounts and roles 
 - Handle booking records and payment transactions 
 
 The repository includes all source code, configuration files, and documentation required to set up and run both applications. It also integrates with various technologies to ensure high performance, security, and scalability. 
 
 Contents 
 - Source code for both DriveHub and Admin applications 
 - Configuration files for database and cloud services 
 - Documentation including installation guide, running instructions, and data management details 
 - Unit tests implemented with xUnit for ensuring code quality 
 - CI/CD pipeline configurations using GitHub Actions 
 - Scripts for setting up and migrating the database 
 
 The repository is structured to facilitate easy deployment and maintenance, making it a powerful tool for managing vehicle reservations and administration efficiently.
 
   Release notes
 - The DriveHub-Final.zip source code is the final release version. This represents the product at Milestone Ω in the project timeline.
 - The DriveHub_Collectors_Edition.zip source code is a special edition optimised for self-hosting and education purposes.
 
    Installation guide
 1. Clone the Repository:
    git clone https://github.com/ProgrammingProject2024SP3Team3/DriveHub.git
    cd drivehub

 2. Install Dependencies:
    Ensure you have the required .NET SDK and other dependencies installed.

 3. Configure the Database:
    Update the `appsettings.Production.json` with your SQL Server connection string.
    {
       "ConnectionStrings": {
          "DriveHubDb": "Server=your_server;Database=your_db;User Id=your_user;Password=your_password;"
       }
    }

 4. Run Migrations:
    Apply the database migrations to set up the database schema.
    dotnet ef database update

 5. Build and Run the Application:
    dotnet build
    dotnet run
 
 Running instructions
 - Register and Login: Users can register and log in to the system.
 - Book a Vehicle: Navigate to the booking page to search and book vehicles.
 - Manage Reservations: View and manage your reservations, extend or cancel bookings.
 - Process Payments: Securely process payments using Stripe.
 - Generate Reports: Generate and download PDF reports and invoices.
 
 GitHub URL
 - DriveHub Repository: https://github.com/ProgrammingProject2024SP3Team3/DriveHub
 
 Current Credentials
 - DriveHubDb: Server=tcp:drivehubaus.database.windows.net,1433;Initial Catalog=DriveHubDb;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;Authentication=\"Active Directory Default\";
 - DriveHubAdminDb: Server=tcp:drivehubaus.database.windows.net,1433;Initial Catalog=DriveHubAdminDb;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;Authentication=\"Active Directory Default\";
 - StripeKey (Dev): sk_test_51QBlxHFqWUoHjTKqFGpJ01qSOCzZRbKVPvlIskkh9ib14aTSPPh6hlCnAYgd6i6ppLaqVpFgiA7czGhUs4RESZWd00bKIdnhHE
 - StripeKey (Prod): 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
 - SendGridKey: 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
