﻿namespace Admin.Models.ViewModels
{
    public class HomeViewModel
    {

    }
}
