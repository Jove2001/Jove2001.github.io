﻿namespace DriveHub.Models.ViewModels
{
    public class PodVM
    {
        public string PodId { get; set; }
        public string PodName { get; set; }
    }
}
